# ChromaSense — Colorimetric Concentration Analyzer

A complete mobile + backend solution for colorimetric analysis.

---

## Architecture

```
Flutter App  →  POST /analyze (multipart: image + ROI coords)  →  Python Server
                                                                        ↓
                                                              Extract mean RGB from ROI
                                                                        ↓
                                                              k-NN match against dataset.csv
                                                                        ↓
                                                              Return concentration + metadata
```

---

## Python Backend Setup

### 1. Install dependencies
```bash
cd python_backend
pip install -r requirements.txt
```

### 2. Replace the dataset
Edit `dataset.csv` — must have these columns:

| Column | Type | Description |
|---|---|---|
| r | int 0-255 | Red channel mean |
| g | int 0-255 | Green channel mean |
| b | int 0-255 | Blue channel mean |
| concentration | float | Known concentration |
| unit | string | e.g. mg/L, ppm, µmol/L |
| analyte | string | e.g. Nitrate, Iron, pH |
| sample_id | string | Unique ID for reference |

### 3. Run the server
```bash
python server.py
```
Server starts at `http://0.0.0.0:5000`

### API Endpoints

| Method | Route | Description |
|---|---|---|
| GET | `/health` | Server + dataset status |
| POST | `/analyze` | Main analysis endpoint |
| GET | `/dataset-info` | Dataset statistics |
| POST | `/reload-dataset` | Hot-reload CSV without restart |

### Hot-reload dataset
After replacing `dataset.csv`:
```bash
curl -X POST http://localhost:5000/reload-dataset
```

---

## Flutter App Setup

### 1. Install dependencies
```bash
cd flutter_app
flutter pub get
```

### 2. Set your server URL
Edit `lib/services/api_service.dart`:
```dart
static const String _baseUrl = 'http://YOUR_SERVER_IP:5000';
```

### 3. Android permissions
Add to `android/app/src/main/AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.INTERNET"/>
<!-- For Android 9+ cleartext (local dev only) -->
<application android:usesCleartextTraffic="true" ...>
```

### 4. iOS permissions
Add to `ios/Runner/Info.plist`:
```xml
<key>NSCameraUsageDescription</key>
<string>Used to capture sample images for analysis</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>Used to select sample images for analysis</string>
```

### 5. Run
```bash
flutter run
```

---

## How It Works

1. **User** taps "Capture" or "Gallery" → selects image
2. **ROI screen** — user draws a rectangle over the sample area
3. App sends: `image file + roi_x, roi_y, roi_width, roi_height` to `/analyze`
4. **Server** crops the ROI, computes mean R, G, B
5. k-Nearest Neighbours (weighted by distance) predicts concentration
6. Confidence = `1 - (distance / threshold)` — drops as RGB drifts from training data
7. **Result screen** shows concentration, RGB bars, match metadata

---

## Customizing the ML Model

In `server.py`, you can change:
- `N_NEIGHBORS = 3` — number of nearest neighbours
- `MAX_DISTANCE_WARN = 50.0` — RGB Euclidean distance above which confidence drops to 0

For larger, more varied datasets, consider switching to a regression model:
```python
from sklearn.ensemble import RandomForestRegressor
self.model = RandomForestRegressor(n_estimators=100)
```

---

## File Structure

```
chromasense/
├── flutter_app/
│   ├── lib/
│   │   ├── main.dart
│   │   ├── screens/
│   │   │   ├── home_screen.dart        # Landing page
│   │   │   ├── roi_selection_screen.dart  # Draw ROI on image
│   │   │   └── result_screen.dart      # Show results
│   │   ├── services/
│   │   │   └── api_service.dart        # HTTP client
│   │   └── models/
│   │       └── analysis_result.dart    # Data model
│   └── pubspec.yaml
└── python_backend/
    ├── server.py                       # Flask API
    ├── dataset.csv                     # Your training data ← REPLACE THIS
    └── requirements.txt
```
