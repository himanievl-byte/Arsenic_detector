class AnalysisResult {
  final double concentration;
  final String unit;
  final double confidence;
  final Map<String, int> rgb;
  final String? matchId;
  final String? analyte;
  final double? distance;
  final String? message;
  final double? threshold;
  final bool? exceedsThreshold;
  final bool? inCalibratedRange;

  AnalysisResult({
    required this.concentration,
    required this.unit,
    required this.confidence,
    required this.rgb,
    this.matchId,
    this.analyte,
    this.distance,
    this.message,
    this.threshold,
    this.exceedsThreshold,
    this.inCalibratedRange,
  });

  factory AnalysisResult.fromJson(Map<String, dynamic> json) {
    final rgbData = json['rgb'] as Map<String, dynamic>;
    return AnalysisResult(
      concentration: (json['concentration'] as num).toDouble(),
      unit: json['unit'] as String? ?? 'mg/L',
      confidence: (json['confidence'] as num).toDouble(),
      rgb: {
        'r': (rgbData['r'] as num).toInt(),
        'g': (rgbData['g'] as num).toInt(),
        'b': (rgbData['b'] as num).toInt(),
      },
      matchId: json['match_id'] as String?,
      analyte: json['analyte'] as String?,
      distance: json['distance'] != null
          ? (json['distance'] as num).toDouble()
          : null,
      message: json['message'] as String?,
      threshold: json['threshold'] != null
          ? (json['threshold'] as num).toDouble()
          : null,
      exceedsThreshold: json['exceeds_threshold'] as bool?,
      inCalibratedRange: json['in_calibrated_range'] as bool?,
    );
  }
}
