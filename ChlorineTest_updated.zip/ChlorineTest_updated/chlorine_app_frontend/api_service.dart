import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/analysis_result.dart';

class ApiService {
  // ⚠️ Change this to your server IP/URL
  static const String _baseUrl = 'http://192.168.1.100:5000';

  static Future<AnalysisResult> analyzeROI({
    required String imagePath,
    required double roiX,
    required double roiY,
    required double roiWidth,
    required double roiHeight,
    String analyte = 'chlorine',
  }) async {
    final uri = Uri.parse('$_baseUrl/analyze');
    final request = http.MultipartRequest('POST', uri);

    // Attach the image file
    final file = File(imagePath);
    final fileExtension = imagePath.split('.').last.toLowerCase();
    final mimeType = fileExtension == 'jpg' || fileExtension == 'jpeg'
        ? 'image/jpeg'
        : 'image/png';

    request.files.add(
      await http.MultipartFile.fromPath(
        'image',
        file.path,
        // contentType: MediaType.parse(mimeType),
      ),
    );

    // Which analyte to run the prediction against (chlorine or arsenic)
    request.fields['analyte'] = analyte;

    // Send ROI coordinates
    request.fields['roi_x'] = roiX.toStringAsFixed(2);
    request.fields['roi_y'] = roiY.toStringAsFixed(2);
    request.fields['roi_width'] = roiWidth.toStringAsFixed(2);
    request.fields['roi_height'] = roiHeight.toStringAsFixed(2);

    final streamedResponse = await request.send().timeout(
      const Duration(seconds: 30),
    );
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      return AnalysisResult.fromJson(json);
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? 'Server error: ${response.statusCode}');
    }
  }
}
