import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'result_screen.dart';
import '../services/api_service.dart';

class ROISelectionScreen extends StatefulWidget {
  final String imagePath;
  final String analyte; // 'chlorine' or 'arsenic'
  const ROISelectionScreen({
    super.key,
    required this.imagePath,
    this.analyte = 'chlorine',
  });

  @override
  State<ROISelectionScreen> createState() => _ROISelectionScreenState();
}

class _ROISelectionScreenState extends State<ROISelectionScreen>
    with SingleTickerProviderStateMixin {
  Offset? _startPoint;
  Offset? _endPoint;
  bool _isDragging = false;
  bool _isAnalyzing = false;
  bool _roiConfirmed = false;
  late AnimationController _shimmerController;

  // Image display info
  double _imageScale = 1.0;
  Offset _imageOffset = Offset.zero;
  Size _imageSize = Size.zero;
  Size _displaySize = Size.zero;

  final GlobalKey _imageKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    )..repeat();
    _loadImageSize();
  }

  Future<void> _loadImageSize() async {
    final file = File(widget.imagePath);
    final bytes = await file.readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    setState(() {
      _imageSize = Size(
        frame.image.width.toDouble(),
        frame.image.height.toDouble(),
      );
    });
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }

  Rect? get _selectionRect {
    if (_startPoint == null || _endPoint == null) return null;
    return Rect.fromPoints(_startPoint!, _endPoint!);
  }

  void _onPanStart(DragStartDetails details) {
    setState(() {
      _startPoint = details.localPosition;
      _endPoint = details.localPosition;
      _isDragging = true;
      _roiConfirmed = false;
    });
  }

  void _onPanUpdate(DragUpdateDetails details) {
    setState(() {
      _endPoint = details.localPosition;
    });
  }

  void _onPanEnd(DragEndDetails details) {
    setState(() {
      _isDragging = false;
      if (_selectionRect != null && _selectionRect!.width > 10 &&
          _selectionRect!.height > 10) {
        _roiConfirmed = true;
      }
    });
  }

  Rect? _getNormalizedROI(Size containerSize) {
    if (_selectionRect == null || _imageSize == Size.zero) return null;

    // Calculate image display bounds within the container
    final imageAspect = _imageSize.width / _imageSize.height;
    final containerAspect = containerSize.width / containerSize.height;

    double imgW, imgH, imgX, imgY;
    if (imageAspect > containerAspect) {
      imgW = containerSize.width;
      imgH = containerSize.width / imageAspect;
      imgX = 0;
      imgY = (containerSize.height - imgH) / 2;
    } else {
      imgH = containerSize.height;
      imgW = containerSize.height * imageAspect;
      imgX = (containerSize.width - imgW) / 2;
      imgY = 0;
    }

    final selRect = _selectionRect!;
    // Convert to image-relative coordinates
    final x1 = ((selRect.left - imgX) / imgW * _imageSize.width)
        .clamp(0.0, _imageSize.width);
    final y1 = ((selRect.top - imgY) / imgH * _imageSize.height)
        .clamp(0.0, _imageSize.height);
    final x2 = ((selRect.right - imgX) / imgW * _imageSize.width)
        .clamp(0.0, _imageSize.width);
    final y2 = ((selRect.bottom - imgY) / imgH * _imageSize.height)
        .clamp(0.0, _imageSize.height);

    return Rect.fromLTRB(x1, y1, x2, y2);
  }

  Future<void> _analyzeROI() async {
    final box =
        _imageKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || _selectionRect == null) return;

    final containerSize = box.size;
    final roi = _getNormalizedROI(containerSize);
    if (roi == null) return;

    setState(() => _isAnalyzing = true);

    try {
      final result = await ApiService.analyzeROI(
        imagePath: widget.imagePath,
        analyte: widget.analyte,
        roiX: roi.left,
        roiY: roi.top,
        roiWidth: roi.width,
        roiHeight: roi.height,
      );

      if (mounted) {
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) =>
                ResultScreen(result: result, imagePath: widget.imagePath),
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) {
              return FadeTransition(opacity: animation, child: child);
            },
            transitionDuration: const Duration(milliseconds: 400),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Analysis failed: ${e.toString()}'),
            backgroundColor: const Color(0xFFFF4757),
            behavior: SnackBarBehavior.floating,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isAnalyzing = false);
    }
  }

  void _resetROI() {
    setState(() {
      _startPoint = null;
      _endPoint = null;
      _roiConfirmed = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E1A),
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildInstructions(),
          Expanded(child: _buildImageCanvas()),
          _buildBottomBar(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF0A0E1A),
      elevation: 0,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.arrow_back_ios_new, size: 16,
              color: Colors.white),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select Region',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            'Draw a box over the sample area',
            style: TextStyle(
              color: Color(0xFF8892A4),
              fontSize: 11,
            ),
          ),
        ],
      ),
      actions: [
        if (_roiConfirmed)
          TextButton(
            onPressed: _resetROI,
            child: const Text(
              'Reset',
              style: TextStyle(color: Color(0xFFFF4757), fontSize: 13),
            ),
          ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildInstructions() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: _roiConfirmed
            ? const Color(0xFF00D4AA).withOpacity(0.1)
            : const Color(0xFFFFB347).withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _roiConfirmed
              ? const Color(0xFF00D4AA).withOpacity(0.3)
              : const Color(0xFFFFB347).withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Icon(
            _roiConfirmed
                ? Icons.check_circle_outline
                : Icons.touch_app_rounded,
            color: _roiConfirmed
                ? const Color(0xFF00D4AA)
                : const Color(0xFFFFB347),
            size: 18,
          ),
          const SizedBox(width: 10),
          Text(
            _roiConfirmed
                ? 'ROI selected! Tap "Analyze" to process.'
                : 'Draw a rectangle over the colored sample area',
            style: TextStyle(
              color: _roiConfirmed
                  ? const Color(0xFF00D4AA)
                  : const Color(0xFFFFB347),
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageCanvas() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: GestureDetector(
          onPanStart: _onPanStart,
          onPanUpdate: _onPanUpdate,
          onPanEnd: _onPanEnd,
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Image
              Image.file(
                File(widget.imagePath),
                fit: BoxFit.contain,
                key: _imageKey,
              ),
              // Dark overlay when ROI is being drawn
              if (_selectionRect != null)
                CustomPaint(
                  painter: OverlayPainter(rect: _selectionRect!),
                ),
              // ROI selection border
              if (_selectionRect != null)
                CustomPaint(
                  painter: ROIPainter(
                    rect: _selectionRect!,
                    confirmed: _roiConfirmed,
                    shimmerValue: _shimmerController.value,
                  ),
                ),
              // Crosshair cursor hint
              if (!_roiConfirmed && _startPoint == null)
                const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.crop_free_rounded,
                          color: Colors.white54, size: 48),
                      SizedBox(height: 12),
                      Text(
                        'Tap and drag to select',
                        style:
                            TextStyle(color: Colors.white38, fontSize: 13),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          if (_roiConfirmed && _selectionRect != null) ...[
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _StatChip(
                    label: 'Width',
                    value:
                        '${_selectionRect!.width.toInt()} px',
                    color: const Color(0xFF6C63FF),
                  ),
                  Container(
                      width: 1, height: 32,
                      color: Colors.white.withOpacity(0.1)),
                  _StatChip(
                    label: 'Height',
                    value:
                        '${_selectionRect!.height.toInt()} px',
                    color: const Color(0xFF00D4AA),
                  ),
                  Container(
                      width: 1, height: 32,
                      color: Colors.white.withOpacity(0.1)),
                  _StatChip(
                    label: 'Area',
                    value:
                        '${(_selectionRect!.width * _selectionRect!.height).toInt()} px²',
                    color: const Color(0xFFFFB347),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
          SizedBox(
            width: double.infinity,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: 56,
              child: ElevatedButton(
                onPressed: _roiConfirmed && !_isAnalyzing
                    ? _analyzeROI
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00D4AA),
                  disabledBackgroundColor: Colors.white.withOpacity(0.08),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: _roiConfirmed ? 8 : 0,
                  shadowColor: const Color(0xFF00D4AA).withOpacity(0.4),
                ),
                child: _isAnalyzing
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2.5,
                            ),
                          ),
                          SizedBox(width: 12),
                          Text(
                            'Analyzing Sample...',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      )
                    : Text(
                        _roiConfirmed
                            ? 'Analyze Concentration'
                            : 'Select ROI First',
                        style: TextStyle(
                          color: _roiConfirmed
                              ? Colors.white
                              : Colors.white.withOpacity(0.3),
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF8892A4),
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class OverlayPainter extends CustomPainter {
  final Rect rect;
  OverlayPainter({required this.rect});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withOpacity(0.45);
    final path = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addRect(rect)
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(OverlayPainter old) => old.rect != rect;
}

class ROIPainter extends CustomPainter {
  final Rect rect;
  final bool confirmed;
  final double shimmerValue;

  ROIPainter({
    required this.rect,
    required this.confirmed,
    required this.shimmerValue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final color = confirmed ? const Color(0xFF00D4AA) : const Color(0xFFFFFFFF);

    // Main border
    final borderPaint = Paint()
      ..color = color.withOpacity(confirmed ? 0.9 : 0.7)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    canvas.drawRect(rect, borderPaint);

    // Corner markers
    const cornerLen = 20.0;
    final cornerPaint = Paint()
      ..color = color
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // Top-left
    canvas.drawLine(
        rect.topLeft, rect.topLeft + const Offset(cornerLen, 0), cornerPaint);
    canvas.drawLine(
        rect.topLeft, rect.topLeft + const Offset(0, cornerLen), cornerPaint);
    // Top-right
    canvas.drawLine(rect.topRight,
        rect.topRight + const Offset(-cornerLen, 0), cornerPaint);
    canvas.drawLine(
        rect.topRight, rect.topRight + const Offset(0, cornerLen), cornerPaint);
    // Bottom-left
    canvas.drawLine(rect.bottomLeft,
        rect.bottomLeft + const Offset(cornerLen, 0), cornerPaint);
    canvas.drawLine(rect.bottomLeft,
        rect.bottomLeft + const Offset(0, -cornerLen), cornerPaint);
    // Bottom-right
    canvas.drawLine(rect.bottomRight,
        rect.bottomRight + const Offset(-cornerLen, 0), cornerPaint);
    canvas.drawLine(rect.bottomRight,
        rect.bottomRight + const Offset(0, -cornerLen), cornerPaint);

    if (!confirmed) {
      // Center crosshair
      final crossPaint = Paint()
        ..color = Colors.white.withOpacity(0.4)
        ..strokeWidth = 1;
      final center = rect.center;
      canvas.drawLine(
          Offset(center.dx - 10, center.dy), Offset(center.dx + 10, center.dy),
          crossPaint);
      canvas.drawLine(
          Offset(center.dx, center.dy - 10), Offset(center.dx, center.dy + 10),
          crossPaint);
    }
  }

  @override
  bool shouldRepaint(ROIPainter old) =>
      old.rect != rect ||
      old.confirmed != confirmed ||
      old.shimmerValue != shimmerValue;
}
